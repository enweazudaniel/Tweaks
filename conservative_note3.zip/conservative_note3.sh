#!/system/bin/sh

# Pause script execution a little for Magisk Boot Service;
sleep 60;

#GMS TWEAKS;
busybox killall -9 com.google.android.gms
busybox killall -9 com.google.android.gms.persistent
busybox killall -9 com.google.process.gapps
busybox killall -9 com.google.android.gsf
busybox killall -9 com.google.android.gsf.persistent

# Completely stop & disable performance daemon at boot;
stop performanced

# Disable sysctl.conf;
if [ -e /system/etc/sysctl.conf ]; then
  mount -o remount,rw /system;
  mv /system/etc/sysctl.conf /system/etc/sysctl.conf.bak;
  mount -o remount,ro /system;
fi;

#Cpu tweaks;
echo "conservative" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo "conservative" > /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
echo "conservative" > /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
echo "conservative" > /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
echo "95" > /sys/devices/system/cpu/cpufreq/conservative/up_threshold
echo "120000" > /sys/devices/system/cpu/cpufreq/conservative/sampling_rate
echo "1" > /sys/devices/system/cpu/cpufreq/conservative/sampling_down_factor
echo "40" > /sys/devices/system/cpu/cpufreq/conservative/down_threshold
echo "10" > /sys/devices/system/cpu/cpufreq/conservative/freq_step
echo "1000000" > /dev/cpuctl/cpu.rt_period_us
chmod 644 /sys/module/cpu_boost/parameters/boost_ms
echo "0" > /sys/module/cpu_boost/parameters/boost_ms
chmod 644 /sys/module/cpu_input_boost/parameters/input_boost_ms
echo "0" > /sys/module/cpu_input_boost/parameters/input_boost_ms
echo "0" > /sys/module/lpm_levels/enable_low_power/l2
echo "1000000" > /proc/sys/kernel/sched_rt_period_us

#I/O;
echo "noop">/sys/block/mmcblk0/queue/scheduler

#GPU TWEAKS;
echo "200000000" > /sys/class/devfreq/fdb00000.qcom,kgsl-3d0/min_freq
echo "450000000" > /sys/class/devfreq/fdb00000.qcom,kgsl-3d0/max_freq
echo "200000000" > /sys/class/devfreq/fdb00000.qcom,kgsl-3d0/cur_freq
echo "170" > /sys/class/leds/led:rgb_blue/max_brightness
echo "170" > /sys/class/leds/led:rgb_green/max_brightness
echo "170" > /sys/class/leds/lcd-backlight/max_brightness
echo "170" > /sys/class/leds/led:flash_torch/max_brightness
echo "170" > /sys/class/leds/led:rgb_red/max_brightness

#MISC;
echo "128" > /proc/sys/net/core/netdev_max_backlog
echo "0" > /proc/sys/net/core/netdev_tstamp_prequeue
echo "24" > /proc/sys/net/ipv4/ipfrag_time
echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control
echo "1" > /proc/sys/net/ipv4/tcp_ecn
echo "0" > /proc/sys/net/ipv4/tcp_fwmark_accept
echo "320" > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo "21600" > /proc/sys/net/ipv4/tcp_keepalive_time
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save
echo "0" > /proc/sys/net/ipv4/tcp_slow_start_after_idle
echo "48" > /proc/sys/net/ipv6/ip6frag_time
setprop debug.sf.hw 1
setprop ro.ril.power_collapse 0
setprop ro.ril.disable.power.collapse 1
setprop persist.sys.use_dithering 0
setprop wifi.supplicant_scan_interval 180
setprop power_supply.wakeup enable
setprop power.saving.mode 1
setprop ro.config.hw_power_saving 1
setprop ro.config.hw_power_saving true
setprop persist.radio.add_power_save 1

# Trim selected partitions at boot;
fstrim /data;
fstrim /cache; 
fstrim /system;

# Auto-generate log directory;
mkdir -p /storage/emulated/0/logs

# Script log file location;
LOG_FILE=/storage/emulated/0/logs

export TZ=$(getprop persist.sys.timezone);
echo $(date) > /storage/emulated/0/logs/conservative.log
if [ $? -eq 0 ]
then
  echo "Successfully applied Enjoy The Tweaks!" >> /storage/emulated/0/logs/conservative.log
  exit 0
else
  echo "Failed...please share logs with me" >> /storage/emulated/0/logs/conservative.log
  exit 1
fi
  
# Wait..
# Done!
#
